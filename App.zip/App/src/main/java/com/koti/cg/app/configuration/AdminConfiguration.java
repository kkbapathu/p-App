package com.koti.cg.app.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;


@Order(1)
@EnableWebSecurity
public class AdminConfiguration extends WebSecurityConfigurerAdapter {

	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private AdminLoginFail loginFail;
	
	@Autowired
	private AdminLogoutSucc adminLogoutHandler;
	
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService);
	}
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		
		http.csrf().disable()
		.antMatcher("/admin/**")
		.authorizeRequests()
		.antMatchers("/admin/log**").permitAll()
		.antMatchers("/admin/**").hasRole("ADMIN")
		.anyRequest().authenticated()
		
		.and()
		.formLogin()
		.loginPage("/admin/login")
		.failureHandler(loginFail)
		.defaultSuccessUrl("/admin/dashboard", false)
		.permitAll()
		
		.and()
		.logout()
		//.logoutSuccessHandler(myLogoutHandler)
		.logoutUrl("/admin/logoutAd")
		.logoutSuccessHandler(adminLogoutHandler)
        .logoutSuccessUrl("/admin/loginAd")
        .deleteCookies("JSESSIONID")
		.permitAll()
		
		.and()
        .exceptionHandling()
        .accessDeniedPage("/admin/logDeniedAd");
	}
}
