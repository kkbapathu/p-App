package com.koti.cg.app.configuration;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

@Component
public class OperatorLoginFail implements AuthenticationFailureHandler {

	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
			
		System.out.println("hello : "+exception.getMessage());
		
		String flag ="1"; // bad password or user not found
		if("User account is locked".equalsIgnoreCase(exception.getMessage())) {
			flag = "2"; // user locked
		}
		else if("User is disabled".equalsIgnoreCase(exception.getMessage())) {
			flag = "3"; // user disabled
		}
		String url = "/operator/login?error="+flag;
		System.out.println("next url : "+url);
		response.sendRedirect(url);
	}

}
