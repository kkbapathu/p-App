package com.koti.cg.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppApplicationTests {

		
		
		@Test
		   public void whenUserIdIsProvided_thenRetrievedNameIsCorrect() {
		   }
	
}
