package com.koti.cg.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer_group")
public class CustomerGroup {

		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private Long customerGroupId;
		
		private String groupName;
		private boolean isActive;
		
		
		public Long getCustomerGroupId() {
			return customerGroupId;
		}
		public void setCustomerGroupId(Long customerGroupId) {
			this.customerGroupId = customerGroupId;
		}
		public String getGroupName() {
			return groupName;
		}
		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}
		public boolean isActive() {
			return isActive;
		}
		public void setActive(boolean isActive) {
			this.isActive = isActive;
		}
		
		
		
		
		
	

}
