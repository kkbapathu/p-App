package com.koti.cg.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "house_information")
public class HouseInfo {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long houseUniqueId;
	
	private String address;
	private String name;
	
	
	
	public Long getHouseUniqueId() {
		return houseUniqueId;
	}
	public void setHouseUniqueId(Long houseUniqueId) {
		this.houseUniqueId = houseUniqueId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
}
