package com.koti.cg.app.controllers;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.koti.cg.app.model.ActiveFee;
import com.koti.cg.app.model.HouseInfo;
import com.koti.cg.app.model.InvoiceDetails;
import com.koti.cg.app.service.ParkingService;
import com.lowagie.text.DocumentException;

@Controller
@RequestMapping({"/operator","/admin","/"})
public class UserController {

	@Autowired
	private ParkingService service;
	
	@GetMapping("/logp")
	 public void logp(HttpServletResponse response) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=Invoice_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
         
        service.genPdf(response,null);
         
    }
	
	
	@GetMapping("/generateInvoice")
	public String generateInvoice(Model model) {
		
		List<Object[]> res = service.getDefaultHouseNames();
		model.addAttribute("res", res);
		return "invoice";
	}
	
	@GetMapping("/getInvoiceList")
	public String getInvoiceList(@RequestParam String house,@RequestParam String vehicleNo,Model model) {
		System.out.println("house : "+house);
		System.out.println("vehicleNo : "+vehicleNo);
		List<InvoiceDetails> res =  service.getInvoiceList(house,vehicleNo);
		model.addAttribute("list", res);
		return "mySearchResult";
	}
	
	@GetMapping("/export")
    public void exportToPDF(HttpServletResponse response,@RequestParam String house,@RequestParam String vehicleNo) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=Invoice_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
         
         
        service.export(response,house,vehicleNo);
         
    }
	
	
	
	@GetMapping("/dashboard")
	public String dashboard(@AuthenticationPrincipal User user,Model model) {
		String username = user.getUsername();
		model.addAttribute("cUser", "admin".equalsIgnoreCase(username)?"admin":"operator");
		return "dashboard";
	}
	
	@GetMapping("/priceUpdate")
	public String priceUpdate(@AuthenticationPrincipal User user,Model model) {
		String username = user.getUsername();
		model.addAttribute("cUser", "admin".equalsIgnoreCase(username)?"admin":"operator");
		if("admin".equalsIgnoreCase(username)) {
			List<ActiveFee> res = service.getActiveFeeList();
			model.addAttribute("list", res);
		}
		return "priceUpdate";
	}
	
	@RequestMapping(value= "/doUp", method = RequestMethod.GET)
	@ResponseBody
	public String doUp(@RequestParam String pkId,@RequestParam String newPrice) {
		System.out.println("pkId : "+pkId);
		System.out.println("newPrice : "+newPrice);
		return service.updatePrice(pkId,newPrice);
	}
	@GetMapping("/getHouseList")
	public String getHouseList(@AuthenticationPrincipal User user,Model model) {
		String username = user.getUsername();
		model.addAttribute("cUser", "admin".equalsIgnoreCase(username)?"admin":"operator");
		if("admin".equalsIgnoreCase(username)) {
			List<HouseInfo> res = service.getHouseList();
			model.addAttribute("list", res);
		}
		return "houseInfo";
	}
	@RequestMapping(value= "/updateHouseDetails", method = RequestMethod.GET)
	@ResponseBody
	public String updateHouseDetails(@RequestParam String pkId,@RequestParam String newName,@RequestParam String newAddress) {
		return service.updateHouseDetails(pkId,newName,newAddress);
	}
	
	@RequestMapping(value= "/addNewHouseDetails", method = RequestMethod.GET)
	@ResponseBody
	public String updateHouseDetails(@RequestParam String newName,@RequestParam String newAddress) {
		return service.addNewHouseDetails(newName,newAddress);
	}
	
	
	
	
	
}
