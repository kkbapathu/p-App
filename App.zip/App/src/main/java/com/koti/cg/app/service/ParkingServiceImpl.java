package com.koti.cg.app.service;

import java.awt.Color;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.koti.cg.app.dao.HouseDao;
import com.koti.cg.app.dao.ParkingDao;
import com.koti.cg.app.model.ActiveFee;
import com.koti.cg.app.model.HouseInfo;
import com.koti.cg.app.model.InvoiceDetails;
import com.koti.cg.app.model.ParkingDetails;
import com.koti.cg.app.vos.InvoiceVo;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

@Service
public class ParkingServiceImpl implements ParkingService {

	private static final DecimalFormat doubleFormat = new DecimalFormat("0.00");
	
	@Autowired
	private ParkingDao parkingDao;

	@Autowired
	private HouseDao houseDao;

	@Override
	public List<ActiveFee> getActiveFeeList() {
		List<ActiveFee> list = new ArrayList<ActiveFee>();
		Iterable<ActiveFee> findAll = parkingDao.findAll();
		if (findAll != null) {
			findAll.forEach(a -> {
				list.add(a);
			});
		}
		return list;
	}

	@Override
	public String updatePrice(String pkId, String newPrice) {
		String res = "0";
		Optional<ActiveFee> findById = parkingDao.findById(Long.parseLong(pkId));
		if (findById.isPresent()) {
			ActiveFee activeFee = findById.get();
			activeFee.setCharges(Double.parseDouble(newPrice));
			parkingDao.save(activeFee);
			res = "1";
		}

		
		
		return res;
	}

	@Override
	public List<HouseInfo> getHouseList() {
		List<HouseInfo> list = new ArrayList<HouseInfo>();
		Iterable<HouseInfo> findAll = houseDao.findAll();
		if (findAll != null) {
			findAll.forEach(a -> {
				list.add(a);
			});
		}
		return list;
	}

	@Override
	public String updateHouseDetails(String pkId, String newName, String newAddress) {
		String res = "0";
		Iterable<HouseInfo> findAll = houseDao.findAll();
		if (findAll != null) {
			Iterator<HouseInfo> iterator = findAll.iterator();
			while (iterator.hasNext()) {
				HouseInfo a = iterator.next();
				if (a.getName().equalsIgnoreCase(newName) && a.getAddress().equalsIgnoreCase(newAddress)) {
					res = "E";
					break;
				}
			}
		}
		if ("E".equals(res) == false) {
			Optional<HouseInfo> findById = houseDao.findById(Long.parseLong(pkId));
			if (findById.isPresent()) {
				HouseInfo houseInfo = findById.get();
				houseInfo.setName(newName);
				houseInfo.setAddress(newAddress);
				houseDao.save(houseInfo);
				res = "1";
			}
		}
		return res;
	}

	@Override
	public String addNewHouseDetails(String newName, String newAddress) {
		String res = "0";
		try {
			Iterable<HouseInfo> findAll = houseDao.findAll();
			if (findAll != null) {
				Iterator<HouseInfo> iterator = findAll.iterator();
				while (iterator.hasNext()) {
					HouseInfo a = iterator.next();
					if (a.getName().equalsIgnoreCase(newName) && a.getAddress().equalsIgnoreCase(newAddress)) {
						res = "E";
						break;
					}
				}
			}
			if ("E".equals(res) == false) {
				HouseInfo houseInfo = new HouseInfo();
				houseInfo.setName(newName);
				houseInfo.setAddress(newAddress);
				houseDao.save(houseInfo);
				res = "1";
			}
		} catch (Exception e) {
			res = "0";
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public List<InvoiceDetails> getInvoiceList(String house, String vehicleNo) {
		List<InvoiceDetails> res = new ArrayList<InvoiceDetails>();
		if (house != null && vehicleNo != null && house.trim() != "" && vehicleNo.trim() != "") {
			List<Object[]> r1 = parkingDao.getResultsByBoth(vehicleNo, Long.parseLong(house));
			r1.stream().forEach(a -> {
				InvoiceDetails i = new InvoiceDetails();
				i.setHouseId(Long.parseLong(String.valueOf(a[0])));
				i.setHouseName(houseDao.findById(Long.parseLong(String.valueOf(a[0]))).get().getName());
				i.setVehicleNo(String.valueOf(a[1]));

				res.add(i);
			});
		} else if (house != null && house.trim() != "") {
			List<Object[]> r2 = parkingDao.getResultsByHouse(Long.parseLong(house));
			r2.stream().forEach(a -> {
				InvoiceDetails i = new InvoiceDetails();
				i.setHouseId(Long.parseLong(String.valueOf(a[0])));
				i.setHouseName(houseDao.findById(Long.parseLong(String.valueOf(a[0]))).get().getName());
				i.setVehicleNo(String.valueOf(a[1]));
				res.add(i);
			});
		} else if (vehicleNo != null && vehicleNo.trim() != "") {
			List<Object[]> r3 = parkingDao.getResultsByVehicleNo(vehicleNo);
			r3.stream().forEach(a -> {
				InvoiceDetails i = new InvoiceDetails();
				i.setHouseId(Long.parseLong(String.valueOf(a[0])));
				i.setHouseName(houseDao.findById(Long.parseLong(String.valueOf(a[0]))).get().getName());
				i.setVehicleNo(String.valueOf(a[1]));

				res.add(i);
			});
		}

		return res;

	}

	@Override
	public List<Object[]> getDefaultHouseNames() {
		return houseDao.getDefaultHouseNames();
	}

	private void writeTableHeader(PdfPTable table) {
		PdfPCell cell = new PdfPCell();
		cell.setBackgroundColor(Color.WHITE);
		cell.setPadding(5);
		cell.setHorizontalAlignment(Paragraph.ALIGN_CENTER);

		Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
		font.setSize(14);
		font.setColor(Color.BLACK);

		cell.setPhrase(new Phrase("S. No", font));

		table.addCell(cell);

		cell.setPhrase(new Phrase("In Time", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Out Time", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Duration", font));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Charges", font));
		table.addCell(cell);
	}

	private Double writeTableData(PdfPTable table, List<ParkingDetails> res,Double dayCharge,Double nightCharge) {
		Double totalAmount=(double) 0;
		table.setHorizontalAlignment(Paragraph.ALIGN_CENTER);
		int sno = 1;
		for (ParkingDetails o : res) {
			
			PdfPCell ca = new PdfPCell();
			
			ca.setHorizontalAlignment(Paragraph.ALIGN_CENTER);
			ca.setPhrase(new Phrase(String.valueOf(sno)));
			table.addCell(ca);
			
			ca.setPhrase(new Phrase(String.valueOf(o.getInTime())));
			table.addCell(ca);
			
			ca.setPhrase(new Phrase(String.valueOf(o.getOutTime())));
			table.addCell(ca);
			
			String duration = findDuration(o.getOutTime(), o.getInTime());
			ca.setPhrase(new Phrase(duration+" Minutes"));
			table.addCell(ca);
			
			Double charges = findCharges(o.getOutTime(), o.getInTime(), o.getCustomerId(),dayCharge,nightCharge);
			double sum = Double.sum(totalAmount, charges);
			totalAmount = sum;
			
			ca.setPhrase(new Phrase(doubleFormat.format(charges)));
			table.addCell(ca);
			sno++;
		}
		
		return totalAmount;
	}

	private Double findCharges(Timestamp outTime, Timestamp inTime, Long customerGroupId,Double dayCharge, Double nightCharge) {
		
		SimpleDateFormat ss = new SimpleDateFormat("yyyy-MM-dd");
		String format = ss.format(new Date(inTime.getTime()));
		System.out.println(format);
		
		
		  Timestamp dayStart = Timestamp.valueOf(format+" 07:00:00"); 
		  Timestamp nightStart = Timestamp.valueOf(format+" 19:00:00"); 
		  Timestamp dayEnd =  nightStart;
		  Timestamp nightEnd = Timestamp.valueOf(format+" 31:00:00"); 
		  
		 if( inTime.compareTo(dayStart)>-1 && inTime.compareTo(dayEnd) <1 
			&&  outTime.compareTo(dayStart)>-1 && outTime.compareTo(dayEnd) <1 	 ) {
			 System.out.println("entry in day & exit in day");
			 long diff = outTime.getTime()-inTime.getTime();
			 Double d = (diff/(double)(30*60*1000));
					
			 return d*dayCharge;
		 } else if( inTime.compareTo(nightStart)>-1 && inTime.compareTo(nightEnd) <1 
					&&  outTime.compareTo(nightStart)>-1 && outTime.compareTo(nightEnd) <1 	 ) {
			 System.out.println("entry in night & exit in night");
			 long diff = outTime.getTime()-inTime.getTime();
			 Double d = (diff/(double)(30*60*1000));
					
			 return d*nightCharge;
		 }
		 else {
			 long diff = outTime.getTime()-inTime.getTime();
			 Double d = (diff/(double)(30*60*1000));
					
			 return d* Double.sum(dayCharge, nightCharge)/2;
		 }
	}

	private String findDuration(Timestamp outTime, Timestamp inTime) {

		long diff = outTime.getTime()-inTime.getTime();
		Double d = (diff/(double)(60*1000));
		return doubleFormat.format(d);
	}

	@Override
	public void export(HttpServletResponse response, String house, String vehicleNo)
			throws DocumentException, IOException {
		InvoiceVo vo = new InvoiceVo();
		Long customerGroupId = (long) 0; 
		
		List<ParkingDetails> entryDetails = new ArrayList<ParkingDetails>();
		List<Object[]> parkingInfo = parkingDao.getInviceParkingInfo(vehicleNo, Long.parseLong(house));
		parkingInfo.stream().forEach(e->{
			ParkingDetails bo = new ParkingDetails();
			bo.setInTime((Timestamp) e[0]);
			bo.setOutTime((Timestamp) e[1]);
			bo.setHouseId(Long.parseLong(String.valueOf(e[2])) );
			bo.setVehicleNo(String.valueOf(e[3]));
			bo.setCustomerId(Long.parseLong(String.valueOf(e[4])));
			entryDetails.add(bo);
		});
		
		vo.setEntryDetails(entryDetails);
		
		Long customerId = vo.getEntryDetails().get(0).getCustomerId(); 
		
		List<Object[]> cInfo = parkingDao.getInviceCustomerInfo(customerId);
		cInfo.stream().forEach(ci->{
			vo.setCustomerName(String.valueOf(ci[0]));
			vo.setCustomerAddress(String.valueOf(ci[1]));
		});
		customerGroupId = Long.parseLong(String.valueOf(cInfo.get(0)[2]));
		
		
		String groupName = parkingDao.getInviceCustomerGroupInfo(customerGroupId);
		vo.setUserType(groupName);
		
		
		List<Object[]> inviceFeeInfo = parkingDao.getInviceFeeInfo(customerGroupId);
		
		inviceFeeInfo.stream().forEach(f->{
			if(Long.parseLong(String.valueOf(f[0])) ==1 || Long.parseLong(String.valueOf(f[0])) ==2) {
				vo.setDayCharge(Double.valueOf(String.valueOf(f[1])));
			}
			else {
				vo.setNightCharge(Double.valueOf(String.valueOf(f[1])));
			}
		});
		
		List<Object[]> houseInfo = parkingDao.getInvoiceHouseInfo(Long.parseLong(house));
		houseInfo.stream().forEach(i->{
			vo.setHouseDetails(i[0]+", "+i[1]);
		});
		vo.setVehicleNo(vehicleNo);
		genPdf(response,vo);
	}

	public List<ParkingDetails> getParkingDetails(String house, String vehicleNo) {

		List<ParkingDetails> res = new ArrayList<ParkingDetails>();
		if (house != null && vehicleNo != null && house.trim() != "" && vehicleNo.trim() != "") {
			List<Object[]> r1 = parkingDao.getAllByBoth(vehicleNo, Long.parseLong(house));
			r1.stream().forEach(a -> {
				ParkingDetails i = new ParkingDetails();
				i.setInTime((Timestamp) a[0]);
				i.setOutTime((Timestamp) a[1]);
				i.setCustomerId(Long.parseLong(String.valueOf(a[2])));
				res.add(i);
			});
		}
		return res;

	}

	@Override
	public void genPdf(HttpServletResponse response, InvoiceVo vo) {
		try {
			
			String customerName = vo.getCustomerName();
			String invoiceNo = String.valueOf(new Random().nextInt(999999999));
			String vehicleNo = vo.getVehicleNo();
			String address = vo.getCustomerAddress();
			String userType = vo.getUserType();
			String houseAddress = vo.getHouseDetails();
			
			
			
			Document document = new Document(PageSize.A4);
			PdfWriter writer = PdfWriter.getInstance(document, response.getOutputStream());
	       
			//writer.setPageEvent(new WatermarkPageEvent());
			
			document.open();
			Font headFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
			headFont.setSize(18);
			headFont.setColor(Color.BLACK);
			
			Font font = FontFactory.getFont(FontFactory.HELVETICA);
			font.setSize(14);
			font.setColor(Color.BLACK);
			
			Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
			titleFont.setSize(14);
			titleFont.setColor(Color.BLACK);
			
			

			Paragraph p = new Paragraph("Invoice Details", headFont);
			p.setAlignment(Paragraph.ALIGN_CENTER);
			document.add(p);
			
			SimpleDateFormat ss = new SimpleDateFormat("dd/MMM/YYYY");
			String cDate = ss.format(new Date());
			
			Phrase phd = new Phrase("Date : ", titleFont);
			phd.add(new Chunk(cDate, font));
			Paragraph pd = new Paragraph(phd);
			pd.setAlignment(Paragraph.ALIGN_RIGHT);
			document.add(pd);
			
			
			Phrase ph1 = new Phrase("Invoice No : ", titleFont);
			ph1.add(new Chunk(invoiceNo, font));
			
			Paragraph pp = new Paragraph(ph1);
			pp.setAlignment(Paragraph.ALIGN_RIGHT);
			document.add(pp);
			
			
			PdfPTable table1 = new PdfPTable(2);
			table1.setWidthPercentage(100f);
			table1.setWidths(new float[] { 1.5f, 1.5f});
			table1.setSpacingBefore(10);
			
			
			PdfPCell cell = new PdfPCell();
			cell.setBorderColor(Color.WHITE);
			cell.setBackgroundColor(Color.WHITE);
			cell.setPadding(5);
			
			cell.setHorizontalAlignment(Paragraph.ALIGN_LEFT);
			Phrase phrase1 = new Phrase("Customer Name : ", titleFont);
			phrase1.add(new Chunk(customerName, font));
			cell.setPhrase(phrase1);
			table1.addCell(cell);
			
			cell.setHorizontalAlignment(Paragraph.ALIGN_RIGHT);
			Phrase phrase2 = new Phrase("Vehicle No : ", titleFont);
			phrase2.add(new Chunk(""+vehicleNo, font));
			cell.setPhrase(phrase2);
			table1.addCell(cell);

			
			document.add(table1);
			
			
			PdfPTable table2 = new PdfPTable(2);
			table2.setWidthPercentage(100f);
			table2.setWidths(new float[] { 1.5f, 1.5f});
			table2.setSpacingBefore(10);
			
			
			PdfPCell cell2 = new PdfPCell();
			cell2.setBorderColor(Color.WHITE);
			cell2.setBackgroundColor(Color.WHITE);
			cell2.setPadding(5);
			
			cell2.setHorizontalAlignment(Paragraph.ALIGN_LEFT);
			Phrase phrase3 = new Phrase("Address : ", titleFont);
			phrase3.add(new Chunk(address, font));
			cell2.setPhrase(phrase3);
			table2.addCell(cell2);
			
			cell2.setHorizontalAlignment(Paragraph.ALIGN_RIGHT);
			Phrase phrase4 = new Phrase("User Type : ", titleFont);
			phrase4.add(new Chunk(userType, font));
			cell2.setPhrase(phrase4);
			table2.addCell(cell2);

			
			document.add(table2);
			
			
			Paragraph p5 = new Paragraph("Entry Details", titleFont);
			p5.setAlignment(Paragraph.ALIGN_LEFT);
			document.add(p5);

			PdfPTable table = new PdfPTable(5);
			table.setWidthPercentage(100f);
			table.setWidths(new float[] { 1.5f, 3.0f, 3.0f, 3.0f, 3.0f });
			table.setSpacingBefore(10);

			writeTableHeader(table);
			Double totalAmount = writeTableData(table,vo.getEntryDetails(),vo.getDayCharge(),vo.getNightCharge());

			document.add(table);
			
			if("premium".equalsIgnoreCase(userType)){
				PdfPTable table7 = new PdfPTable(2);
				table7.setWidthPercentage(100f);
				table7.setWidths(new float[] { 10.5f, 3.0f });

				PdfPCell cell7 = new PdfPCell();
				cell7.setBackgroundColor(Color.WHITE);
				cell7.setPadding(5);
				
				cell7.setHorizontalAlignment(Paragraph.ALIGN_RIGHT);
				cell7.setPhrase(new Phrase("Monthly Fee : ", titleFont));
				
				table7.addCell(cell7);
				
				cell7.setHorizontalAlignment(Paragraph.ALIGN_LEFT);
				cell7.setPhrase(new Phrase("20.00 EUR", font));
				table7.addCell(cell7);

				document.add(table7);
				
				if(totalAmount>300) {

					PdfPTable table8 = new PdfPTable(2);
					table8.setWidthPercentage(100f);
					table8.setWidths(new float[] { 10.5f, 3.0f });

					PdfPCell cell8= new PdfPCell();
					cell8.setBackgroundColor(Color.WHITE);
					cell8.setPadding(5);
					
					cell8.setHorizontalAlignment(Paragraph.ALIGN_RIGHT);
					cell8.setPhrase(new Phrase("Discount for Premium User : ", titleFont));
					
					table8.addCell(cell8);
					
					cell8.setHorizontalAlignment(Paragraph.ALIGN_LEFT);
					double sum = Double.sum(totalAmount, -300);
					cell8.setPhrase(new Phrase(doubleFormat.format(sum) +"  EUR", font));
					table8.addCell(cell8);

					document.add(table8);
				
					
				}
			}
			
			
			PdfPTable table7 = new PdfPTable(2);
			table7.setWidthPercentage(100f);
			table7.setWidths(new float[] { 10.5f, 3.0f });

			PdfPCell cell7 = new PdfPCell();
			cell7.setBackgroundColor(Color.WHITE);
			cell7.setPadding(5);
			
			cell7.setHorizontalAlignment(Paragraph.ALIGN_RIGHT);
			cell7.setPhrase(new Phrase("Total Charges", titleFont));
			
			table7.addCell(cell7);
			
			cell7.setHorizontalAlignment(Paragraph.ALIGN_LEFT);
			double sum = Double.sum(20.00, totalAmount);
			cell7.setPhrase(new Phrase(("premium".equalsIgnoreCase(userType) ? doubleFormat.format(totalAmount>300?320:sum) : doubleFormat.format(totalAmount) ) +" EUR",titleFont ));
			table7.addCell(cell7);

			document.add(table7);
			
			
			Phrase phrase7 = new Phrase("House Address : ", titleFont);
			phrase7.add(new Chunk(houseAddress, font));
			Paragraph p7 = new Paragraph(phrase7);
			p7.setAlignment(Paragraph.ALIGN_LEFT);
			document.add(p7);
			document.add(new Phrase(" "));
			
			PdfPTable table9 = new PdfPTable(2);
			table9.setWidthPercentage(100f);
			table9.setWidths(new float[] { 1.5f, 1.5f});
			
			
			PdfPCell cell9 = new PdfPCell();
			cell9.setBorderColor(Color.WHITE);
			cell9.setBackgroundColor(Color.WHITE);
			
			cell9.setHorizontalAlignment(Paragraph.ALIGN_LEFT);
			Phrase phrase8 = new Phrase("Generated by : ", titleFont);
			phrase8.add(new Chunk("Operator", font));
			cell9.setPhrase(phrase8);
			table9.addCell(cell9);
			
			cell9.setHorizontalAlignment(Paragraph.ALIGN_RIGHT);
			Phrase phrase9 = new Phrase("Generated On - ", titleFont);
			SimpleDateFormat s = new SimpleDateFormat("dd:MM:yyyy HH:mm:ss");
			phrase9.add(new Chunk(s.format(new Date()), font));
			cell9.setPhrase(phrase9);
			table9.addCell(cell9);

			
			document.add(table9);
			
			
			Phrase phrase10 = new Phrase("Note : ", titleFont);
			phrase10.add(new Chunk(" This is system generated document, No seal and signature is required", font));
			
			Paragraph p8 = new Paragraph(phrase10);
			p8.setAlignment(Paragraph.ALIGN_LEFT);
			document.add(p8);

			document.close();

		} catch (Exception e) {
			try {
			Document document = new Document(PageSize.A4);
			PdfWriter.getInstance(document, response.getOutputStream());
			document.open();
			Paragraph p = new Paragraph("Something went wrong, please contact ADMIN");
			p.setAlignment(Paragraph.ALIGN_CENTER);
			document.add(new Paragraph(""));
			document.add(new Paragraph(""));
			document.add(new Paragraph(""));
			document.add(p);
			document.close();
			}catch (Exception ee) {
			}
			e.printStackTrace();
		}

	}

	private void writeTableData(PdfPTable table, List<InvoiceVo> invoiceDetails, String user) {
		
	}

	private List<InvoiceVo> getInvoiceDetails(String string, String string2) {
		return null;
	}
}
