package com.koti.cg.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer_information")
public class CustomerDetails {

		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private Long customerId;
		
		private String name;
		private String address;
		private boolean isActive;
		private Long customerGroupId;
		
		public Long getCustomerId() {
			return customerId;
		}	

		public void setCustomerId(Long customerId) {
			this.customerId = customerId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public boolean isActive() {
			return isActive;
		}

		public void setActive(boolean isActive) {
			this.isActive = isActive;
		}


		public Long getCustomerGroupId() {
			return customerGroupId;
		}

		public void setCustomerGroupId(Long customerGroupId) {
			this.customerGroupId = customerGroupId;
		}

		
		
		
		
	

}
