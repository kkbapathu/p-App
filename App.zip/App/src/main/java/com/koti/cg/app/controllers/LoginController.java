package com.koti.cg.app.controllers;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Bean;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.ExceptionMappingAuthenticationFailureHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
public class LoginController {

	
	@Bean
	public ExceptionMappingAuthenticationFailureHandler ss() {
		return new ExceptionMappingAuthenticationFailureHandler();
	}
	
	
	
	@RequestMapping(value = "/operator/login", method = RequestMethod.GET)
    public String login(ModelMap model, String error, String logout, @AuthenticationPrincipal User user) {
		
		System.out.println("error:"+error+",logout:"+logout+", login & logout time : "+new Date());
        if (error != null) {
            model.addAttribute("errorMsg",error);
        }
        if (logout != null) {
        	//model.addAttribute("msg", "You have been logged out successfully.");
        	return "redirect:/klogout";
        }
        if(user!=null && user.getUsername()!=null && user.getUsername().trim()!="") {
        	if("operator".equalsIgnoreCase(user.getUsername())) {
        		return "redirect:/operator/generateInvoice";
        	}
        	else {
        		return "redirect:/operator/dashboard";
        	}
        }
        return "op-login";
    }
	
	@GetMapping("/klogout")
	public String logout(HttpServletRequest req) {
		 System.out.println("kk kk kk logout time : "+new Date());
		return "logout";
	}
	
	
	
	@RequestMapping(value = "/admin/login", method = RequestMethod.GET)
    public String adminlogin(ModelMap model, String error, String logout, @AuthenticationPrincipal User user) {
		
		System.out.println("error:"+error+",logout:"+logout+", login & logout time : "+new Date());
        if (error != null) {
            model.addAttribute("errorMsg",error);
        }
        if (logout != null) {
        	model.addAttribute("errorMsg","4");
        }
        if(user!=null && user.getUsername()!=null && user.getUsername().trim()!="") {
        	return "redirect:/admin/admDashboard";
        }
        return "admin-login";
    }
	
	@GetMapping("/admin/logDeniedAd")
	public String logDenied(Model model,@AuthenticationPrincipal User user) {
		model.addAttribute("cUser", "admin".equalsIgnoreCase(user.getUsername())?"admin":"operator");
		return "denied";
	}
	
	@GetMapping("/operator/logDeniedUs")
	public String logDeniedUs(Model model,@AuthenticationPrincipal User user) {
		model.addAttribute("cUser", "admin".equalsIgnoreCase(user.getUsername())?"admin":"operator");
		return "denied";
	}

	@GetMapping("/admin/loginAd")
	public String loginAd(Model model) {
		System.out.println("5/admin/loginAd");
		model.addAttribute("cUser", "admin");
		return "logout";
	}
	@GetMapping("/operator/loginAd")
	public String oploginAd(Model model) {
		model.addAttribute("cUser", "operator");
		return "logout";
	}
	@GetMapping("/operator/loginUs")
	public String loginUs(Model model) {
		System.out.println("6/user/loginUs");
		model.addAttribute("cUser", "user");
		return "logout";
	}
}
