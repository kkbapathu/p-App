package com.koti.cg.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.koti.cg.app.model.ActiveFee;

public interface ParkingDao extends CrudRepository<ActiveFee, Long>{

	
	@Query(value = "SELECT distinct house_id,vehicle_no FROM parking_information WHERE vehicle_no = ?1", nativeQuery = true)
	List<Object[]> getResultsByVehicleNo(String vehicleNo);
	
	@Query(value = "SELECT distinct house_id,vehicle_no FROM parking_information WHERE house_id = ?1", nativeQuery = true)
	List<Object[]> getResultsByHouse(Long house);
	
	@Query(value = "SELECT distinct house_id,vehicle_no FROM parking_information WHERE vehicle_no = ?1 and house_id = ?2", nativeQuery = true)
	List<Object[]> getResultsByBoth(String vehicleNo,Long house);
	
	
	@Query(value = "SELECT in_time,out_time,customer_id FROM parking_information WHERE vehicle_no = ?1", nativeQuery = true)
	List<Object[]> getAllByBoth(String vehicleNo,Long house);

	@Query(value = "SELECT customer_id FROM parking_information limit 1", nativeQuery = true)
	String getMyName();

	
	@Query(value = "select in_time,out_time,house_id,vehicle_no,customer_id from parking_information WHERE vehicle_no = ?1 and house_id = ?2", nativeQuery = true)
	List<Object[]> getInviceParkingInfo(String vehicleNo, long parseLong);
	
	@Query(value = "select name,address,customer_group_id from customer_information where customer_id = ?1", nativeQuery = true)
	List<Object[]> getInviceCustomerInfo(long customerId);

	@Query(value = "select group_name from customer_group where customer_group_id = ?1", nativeQuery = true)
	String getInviceCustomerGroupInfo(long customerGroupId);

	@Query(value = "select fee_id,charges from active_fee where customer_group_id = ?1", nativeQuery = true)
	List<Object[]> getInviceFeeInfo(long customerGroupId);

	@Query(value = "select name,address from house_information where house_unique_id = ?1", nativeQuery = true)
	List<Object[]> getInvoiceHouseInfo(long parseLong);
}
