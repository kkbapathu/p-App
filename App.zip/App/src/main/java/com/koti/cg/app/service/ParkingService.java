package com.koti.cg.app.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.koti.cg.app.model.ActiveFee;
import com.koti.cg.app.model.HouseInfo;
import com.koti.cg.app.model.InvoiceDetails;
import com.koti.cg.app.model.ParkingDetails;
import com.koti.cg.app.vos.InvoiceVo;
import com.lowagie.text.DocumentException;

public interface ParkingService {

	List<ActiveFee> getActiveFeeList();

	String updatePrice(String pkId, String newPrice);

	List<HouseInfo> getHouseList();

	String updateHouseDetails(String pkId, String newName, String newAddress);

	String addNewHouseDetails(String newName, String newAddress);

	List<InvoiceDetails> getInvoiceList(String house, String vehicleNo);

	List<Object[]> getDefaultHouseNames();

	void export(HttpServletResponse response, String house, String vehicleNo) throws DocumentException, IOException;

	void genPdf(HttpServletResponse response, InvoiceVo vo);

	default String  getMyName() {
		return "koti reddy";
	}


}
