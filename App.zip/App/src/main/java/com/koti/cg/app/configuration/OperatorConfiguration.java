package com.koti.cg.app.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;


@Order(2)
@EnableWebSecurity
public class OperatorConfiguration extends WebSecurityConfigurerAdapter {

	
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private OperatorLoginFail loginFail;
	
	@Autowired
	private OperatorLogoutSucc operatorLogoutHandler;
	
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService);
	}
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		
		http.csrf().disable()
		.antMatcher("/operator/**")
		.authorizeRequests()
		.antMatchers("/operator/log**").permitAll()
		.antMatchers("/operator/**").hasRole("OPERATOR")
		.anyRequest().authenticated()
		
		.and()
		.formLogin()
		.loginPage("/operator/login")
		.failureHandler(loginFail)
		.defaultSuccessUrl("/operator/generateInvoice", false)
		.permitAll()
		
		.and()
		.logout()
		//.logoutSuccessHandler(myLogoutHandler)
		.logoutUrl("/operator/logoutAd")
		.logoutSuccessHandler(operatorLogoutHandler)
        .logoutSuccessUrl("/operator/loginAd")
        .deleteCookies("JSESSIONID")
		.permitAll()
		
		.and()
        .exceptionHandling()
        .accessDeniedPage("/operator/logDeniedUs");
	}
}
