package com.koti.cg.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "active_fee")
public class ActiveFee {

		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		private Long feeId;
		
		private Long customerGroupId;
		private String baseTime;
		private Double charges;
		private String timePeriod;
		private boolean isActive;
		
		
		public Long getFeeId() {
			return feeId;
		}
		public void setFeeId(Long feeId) {
			this.feeId = feeId;
		}
		public Long getCustomerGroupId() {
			return customerGroupId;
		}
		public void setCustomerGroupId(Long customerGroupId) {
			this.customerGroupId = customerGroupId;
		}
		public String getBaseTime() {
			return baseTime;
		}
		public void setBaseTime(String baseTime) {
			this.baseTime = baseTime;
		}
	
		public Double getCharges() {
			return charges;
		}
		public void setCharges(Double charges) {
			this.charges = charges;
		}
		public String getTimePeriod() {
			return timePeriod;
		}
		public void setTimePeriod(String timePeriod) {
			this.timePeriod = timePeriod;
		}
		public boolean isActive() {
			return isActive;
		}
		public void setActive(boolean isActive) {
			this.isActive = isActive;
		}
		@Override
		public String toString() {
			return "ActiveFee [feeId=" + feeId + ", customerGroupId=" + customerGroupId + ", baseTime=" + baseTime
					+ ", charges=" + charges + ", timePeriod=" + timePeriod + ", isActive=" + isActive + "]";
		}
		
		
	

}
