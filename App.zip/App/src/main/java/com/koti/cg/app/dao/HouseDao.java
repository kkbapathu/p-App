package com.koti.cg.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.koti.cg.app.model.HouseInfo;

public interface HouseDao extends CrudRepository<HouseInfo, Long>{

	@Query(value = "SELECT distinct house_unique_id,name FROM house_information", nativeQuery = true)
	List<Object[]> getDefaultHouseNames();
	

}
