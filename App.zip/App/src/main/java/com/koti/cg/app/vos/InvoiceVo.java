package com.koti.cg.app.vos;

import java.util.List;

import com.koti.cg.app.model.ParkingDetails;

public class InvoiceVo {

	
	private String invoiceNo;
	private String customerName;
	private String vehicleNo;
	private String customerAddress;
	private String userType;
	private List<ParkingDetails> entryDetails;
	private String houseDetails;
	private Double dayCharge;
	private Double nightCharge;
	
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public List<ParkingDetails> getEntryDetails() {
		return entryDetails;
	}
	public void setEntryDetails(List<ParkingDetails> entryDetails) {
		this.entryDetails = entryDetails;
	}
	public String getHouseDetails() {
		return houseDetails;
	}
	public void setHouseDetails(String houseDetails) {
		this.houseDetails = houseDetails;
	}
	public Double getDayCharge() {
		return dayCharge;
	}
	public void setDayCharge(Double dayCharge) {
		this.dayCharge = dayCharge;
	}
	public Double getNightCharge() {
		return nightCharge;
	}
	public void setNightCharge(Double nightCharge) {
		this.nightCharge = nightCharge;
	}
	
	
	
	
	
	
	
}
